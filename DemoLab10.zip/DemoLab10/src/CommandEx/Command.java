package CommandEx;

public interface Command {
    void execute(File file);
}
